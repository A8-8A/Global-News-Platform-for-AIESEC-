package org.aiesec.news.exception;

/**
 * Raised when a requested resource (post, comment, user) does not exist.
 * Mapped to HTTP 404.
 */
public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }
}
